# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Aircraft(Component):
    """An Aircraft component.
Aircraft model

Keyword arguments:

- aircraftRef (boolean | number | string | dict | list; optional):
    Reference to aircraft, created in parent.

- color (boolean | number | string | dict | list; optional):
    Color to use for aircraft model.

- index (number; optional):
    Index of aircraft in scene.

- modelFile (string; optional):
    Path to aircraft model file (gltf/glb).

- playbackSpeed (number; optional):
    Interval in milliseconds.

- playing (boolean; optional):
    Whether playback is active.

- positionData (dict; optional):
    Current position.

    `positionData` is a dict with keys:

    - bank (number; optional)

    - heading (number; optional)

    - pitch (number; optional)

    - x (number; optional)

    - y (number; optional)

    - z (number; optional)"""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'flight_path'
    _type = 'Aircraft'
    @_explicitize_args
    def __init__(self, positionData=Component.UNDEFINED, modelFile=Component.UNDEFINED, playing=Component.UNDEFINED, playbackSpeed=Component.UNDEFINED, aircraftRef=Component.UNDEFINED, color=Component.UNDEFINED, index=Component.UNDEFINED, **kwargs):
        self._prop_names = ['aircraftRef', 'color', 'index', 'modelFile', 'playbackSpeed', 'playing', 'positionData']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['aircraftRef', 'color', 'index', 'modelFile', 'playbackSpeed', 'playing', 'positionData']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Aircraft, self).__init__(**args)
