# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class HoverInfo(Component):
    """A HoverInfo component.
Show information about currently hovered point.

Keyword arguments:

- data (dict; optional):
    Data of current point containing at least x, y, and z, plus
    `fields.

- fields (list; optional):
    Names of fields to show from `data`."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'flight_path'
    _type = 'HoverInfo'
    @_explicitize_args
    def __init__(self, data=Component.UNDEFINED, fields=Component.UNDEFINED, **kwargs):
        self._prop_names = ['data', 'fields']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['data', 'fields']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(HoverInfo, self).__init__(**args)
