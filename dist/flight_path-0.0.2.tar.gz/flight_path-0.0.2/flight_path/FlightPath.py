# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class FlightPath(Component):
    """A FlightPath component.
3D flight trjaectory plot

Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- clickData (dict; optional):
    Updated on click.

- counter (number; default 0):
    Numeric index into data.

- data (list; optional):
    Data containing flight trajectory coordinates and flight
    parameters.:w.

- headingOffset (number; default 0):
    Degrees to offset heading rotation of aircraft model.

- hoverData (dict; optional):
    Prop on hover.

- hoverInfoFields (list; default [    'x',    'y',    'z',    'alt',    'ralt',    'heading',    'bank',    'pitch',    'wow',]):
    Fields in data to show in hover info.

- modelFile (string; optional):
    Path to aircraft model file (gltf/glb).

- playbackSpeed (number; default 1000):
    Playback speed in ms. Value should be synchronized with interval
    component which updates counter.

- playing (boolean; optional):
    Set to True to animate playback.

- segmentInfo (list; optional):
    Segment info.

- traceTitles (list; optional):
    Names of traces, ordered as data."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'flight_path'
    _type = 'FlightPath'
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, data=Component.UNDEFINED, segmentInfo=Component.UNDEFINED, counter=Component.UNDEFINED, modelFile=Component.UNDEFINED, playing=Component.UNDEFINED, playbackSpeed=Component.UNDEFINED, hoverData=Component.UNDEFINED, clickData=Component.UNDEFINED, hoverInfoFields=Component.UNDEFINED, traceTitles=Component.UNDEFINED, headingOffset=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'clickData', 'counter', 'data', 'headingOffset', 'hoverData', 'hoverInfoFields', 'modelFile', 'playbackSpeed', 'playing', 'segmentInfo', 'traceTitles']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'clickData', 'counter', 'data', 'headingOffset', 'hoverData', 'hoverInfoFields', 'modelFile', 'playbackSpeed', 'playing', 'segmentInfo', 'traceTitles']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(FlightPath, self).__init__(**args)
